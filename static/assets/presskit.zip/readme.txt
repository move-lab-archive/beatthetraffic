Beat the traffic is an AI based mini game where you create a mobility wonderland in cities around the world.

Players can globally enchant traffic jams at iconic locations and turn them into nicer things like unicorns, rainbows and driving trees. Traffic participants are detected by computer vision based on machine learning, which allows the game to know where, what and how things are moving through the concrete jungle. It’s on the players dexterity to transform cars and collect all bonus points. 

Once players have beaten the traffic in their city they may submit their highscore. After every game our mobility heroes also learn how many cars they’ve transformed and how few busses would have been needed for transporting their passengers. 

Additional Material
	Images Attached
	Video: https://vimeo.com/263125712 // https://youtu.be/PXIi4Z7bsdI
